#ifndef	_FTRUNCATE64_H_
#define	_FTRUNCATE64_H_

#ifdef	__WINDOWS__
#include	<unistd.h>
#include	<windows.h>

BOOL	SetFileSize(HANDLE h, LONGLONG size);
int	ftruncate64(int fd, off_t length);

#endif	//__WINDOWS__
#endif

/* Specification.  */
