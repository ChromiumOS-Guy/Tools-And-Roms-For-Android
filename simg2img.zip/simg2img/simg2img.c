/*
 * Copyright (C) 2010 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * <name>simg2img</name>
 * <version>1.01</version>
 * <spaces_per_tabs>3</spaces_per_tabs>
 * <description></description>
 * <versions>
 * <version><number>1.0</number><date>2010-xx-xx</date>
 * <author>Unknown, Android open source project</author>
 * </version>
 * <version><number>1.01</number>
 * <date>2015-07-06</date>author>8ohmh</author>
 * <desc>Added getopt, debugging messages by option</desc>
 * </version>
 * </versions>
 */

#include	<sys/types.h>
#include	<sys/stat.h>
#include	<sys/types.h>
#include	<unistd.h>
#include	<fcntl.h>
#include	<stdio.h>
#include	<io.h>
#include	<malloc.h>
#include	<string.h>
#include	<process.h>
#include	<stdarg.h>

// LINUX
// #include <sys/mman.h>

#ifdef	__WINDOWS__		// Windows
#ifdef	__WATCOMC__ 	// Watcom
#include	<windows.h>
#include	<winnt.h>
#include	<winbase.h>
#include	<errno.h>
#include	"ftruncate64.h"
#define	LSEEK64	_lseeki64

#include <mbstring.h>
#endif	//iddef __WATCOMC__
#else
#define	LSEEK64	lseek64
#endif	//ifdef __WINDOWS__

#include "ext4_utils.h"
#include "sparse_format.h"
#include "sparse_crc32.h"

#define	COPY_BUF_SIZE ((1024*1024)*sizeof(unsigned char))

#define	FPRINTF_SEPARATION_BAR	\
	if(debug_msg)	\
		fprintf(output, "--------------------------------------------------------------------------------\n")

#define	PRINT_FILEPOS(x, y)	\
	a_dbg_print( 0,0, y"filepos: 0x%llX\n", _telli64((x)))

FILE	*output;
BOOL	debug_msg;
static	u8	*copybuf;

/* This will be malloc'ed with the size of blk_sz from the sparse file header */
static	u8	*zerobuf;

#define SPARSE_HEADER_MAJOR_VER	1
#define SPARSE_HEADER_LEN	(sizeof(sparse_header_t))
#define CHUNK_HEADER_LEN	(sizeof(chunk_header_t))

static char	**_largv;
static int	indent;

void usage()
{
	fprintf(
		stderr,
		"Usage: %.256s -[d?] -i <chunked image file> -o <unchunked name>\n"
		"-i <sparse_image_file>\n"
		"-o <raw_image_file>\n"
		"-d (debug/img detail messages)\n"
		"-? (This Help)\nby 8ohmh)\n\n",
		_largv[0]);
}

void a_dbg_print(int indbef, int indaft, const char* format, ...)
{
	int	i;
	va_list argptr;
	if(debug_msg == TRUE)
	{
		indent+= indbef;
		if(indent < 0)
			indent= 0;
		if(indent > 80)
			indent= 80;

		for(i= 0; (i < indent); i++)
			fprintf(stderr, "\t");
		va_start(argptr, format);
		vfprintf(stderr, format, argptr);
		va_end(argptr);
		indent+= indaft;
	}
}

long int read_all(int fd, void *buf, size_t len)
{
	size_t	total = 0;
	int ret;
	size_t slen;
	char *ptr = buf;
	long int temp= 0;
	int	i= 0;
	slen= (long int) len;

	a_dbg_print(0, 1, __func__" (begin)\n");

	while(total < len)
	{
		a_dbg_print(0, 0, "index: %x\n", i);
		i++;
		temp= len-total;
		PRINT_FILEPOS(fd, "input ");
		a_dbg_print(0, 0, "temp: 0x%lX\tlen: 0x%lX\n",  len-total,  len);
		ret= (long int) read(fd, ptr, temp);

		a_dbg_print(0, 0,
			"ptr: 0x%p\tlen - total: 0x%lX\ttotal: 0x%lX\tret: 0x%lX\n",
			ptr,
			temp,
			total,
			ret);

		if (ret < 0)
			return ret;

		if (ret == 0)
			return total;

		ptr += ret;
		total += ret;
	}
	PRINT_FILEPOS(fd, "input ");
a_dbg_print(-1, 0, __func__" (end)\n");
	return total;
}

int write_all(int fd, void *buf, size_t len)
{
	size_t total = 0;
	int ret;
	char *ptr = buf;
	int temp= 0;
	a_dbg_print(0, 1, __func__" begin\n");

	PRINT_FILEPOS(fd,"output ");

	while (total < len)
	{
		temp= len - total;
		ret = write(fd, ptr, temp);
		a_dbg_print(0, 0,
			"write_all:\tptr=0x%p\tlen-total=0x%lX\tret=0x%lX\n",
			ptr,
			temp,
			ret);
		if (ret < 0)
			return ret;

		if (ret == 0)
			return total;

		ptr += ret;
		total += ret;
	}

	PRINT_FILEPOS(fd,"output ");
	a_dbg_print(-1, 0, __func__" end\n");
	return total;
}

int process_raw_chunk(int in, int out, u32 blocks, u32 blk_sz, u32 *crc32)
{
	u64	len = (u64)blocks * (u64)blk_sz;
	int ret;
	int chunk;
	a_dbg_print(0, 1, __func__" (begin) \n");
	while(len)
	{
		PRINT_FILEPOS(in, "input ");
		a_dbg_print(0, 0, "len=0x%llX\n", len);
		chunk = (len > COPY_BUF_SIZE) ? COPY_BUF_SIZE : len;
		ret = read_all(in, copybuf, chunk);
		a_dbg_print(0, 0,
			"read_all returns: 0x%lX\n",
			ret);
		if (ret != chunk)
		{
			fprintf(
				output,
				"Read returned an error copying a raw chunk: %d %d\n",
				ret,
				chunk);
			exit(-1);
		}
		a_dbg_print(0, 0,
			"len=0x%lX\tcopybuf=0x%p\tchunk=0x%lX\n",
			len,
			copybuf,
			chunk);
		*crc32 = sparse_crc32(*crc32, copybuf, chunk);

		ret = write_all(out, copybuf, chunk);

		if (ret != chunk)
		{
			fprintf(output, "write returned an error copying a raw chunk\n");
			exit(-1);
		}
		len -= chunk;
	}
	PRINT_FILEPOS(in, "input ");
	a_dbg_print(-1, 0, __func__" (end) \n");
	return blocks;
}

int process_fill_chunk(int in, int out, u32 blocks, u32 blk_sz, u32 *crc32)
{
	u64 len = (u64)blocks * blk_sz;
	int ret;
	int chunk;
	u32 fill_val;
	u32 *fillbuf;
	unsigned int i;

	/* Fill copy_buf with the fill value */
	PRINT_FILEPOS(in,"input ");
	ret = read_all(in, &fill_val, sizeof(fill_val));
	fillbuf = (u32 *)copybuf;
	for (i = 0; i < (COPY_BUF_SIZE / sizeof(fill_val)); i++)
	{	fillbuf[i] = fill_val;	}

	while (len)
	{
		chunk = (len > COPY_BUF_SIZE) ? COPY_BUF_SIZE : len;
		*crc32 = sparse_crc32(*crc32, copybuf, chunk);
		ret = write_all(out, copybuf, chunk);
		if (ret != chunk)
		{
			fprintf(output, "write returned an error copying a raw chunk\n");
			exit(-1);
		}
		len -= chunk;
	}
	PRINT_FILEPOS(in,"input ");
	return blocks;
}

int process_skip_chunk(int out, u32 blocks, u32 blk_sz, u32 *crc32)
{
	/* len needs to be 64 bits, as the sparse file specifies the skip amount
	 * as a 32 bit value of blocks.
	 */
	u64 len = (u64)blocks * blk_sz;
	a_dbg_print(0, 1, __func__" (begin)\n");
	PRINT_FILEPOS(out,"output ");
	LSEEK64(out, len, SEEK_CUR);
	PRINT_FILEPOS(out,"output ");
	a_dbg_print(-1, 0, __func__" (end)\n");
	return blocks;
}

int process_crc32_chunk(int in, u32 crc32)
{
	u32 file_crc32;
	int ret;
	a_dbg_print(0, 1, __func__" (begin)\n");
	PRINT_FILEPOS(in, "input ");
	ret = read_all(in, &file_crc32, 4);
	if (ret != 4)
	{
		fprintf(output, "read returned an error copying a crc32 chunk\n");
		exit(-1);
	}

	if (file_crc32 != crc32)
	{
		a_dbg_print(0, 0,
			"computed crc32 of 0x%8.8x, expected 0x%8.8x\n",
			crc32,
			file_crc32);
		exit(-1);
	}
	PRINT_FILEPOS(in,"input ");
	a_dbg_print(-1, 0, __func__" (end)\n");
	return 0;
}

int main(int argc, char *argv[])
{
	int in, out, i, ret, c;
	sparse_header_t sparse_header;
	chunk_header_t chunk_header;
	u32 crc32 = 0;
	u32 total_blocks = 0;
	u8	*in_filename= NULL;
	u8 *out_filename= NULL;
	debug_msg= FALSE;

	output= stderr;
	//output= fopen("output.txt", "wb");

	indent= 0;
	_largv= argv;
	opterr= 1;

	i= 0;
	while(((c= getopt( argc, argv, ":i:o:d?" )) != -1 ) && ( i < 100) )
	{
		i++;
		switch(c)
		{
			case	'd':
				debug_msg= TRUE;
				break;
			case	'i':
				in_filename = strdup(optarg);
				fprintf(output, "packed img filename: %.256s\n", in_filename);
				break;
			case	'o':
				out_filename = strdup(optarg);
				fprintf(output, "output img filename: %.256s\n", out_filename);
				break;
			case ':':
				printf( "-%c without filename\n", optopt );
				usage();
				exit(-1);
				break;
			case	'?':
				usage();
				exit(-1);
				break;
		}
	}


	if(in_filename == NULL)
	{
		in= STDIN_FILENO;
		fprintf(output, "Using STDIN as input\n");
	}
	else
	{
		in= open(in_filename, O_RDONLY | O_BINARY );
		if(in == 0)
		{
			fprintf(output, "Cannot open input file \"%.256s\n\"", argv[1]);
			exit(-1);
		}
	}

	if(out_filename == NULL)
	{
		out= STDOUT_FILENO;
		fprintf(output, "Using STDOUT as output\n");
	}
	else
	{
		if ((out=
			open( out_filename,
				O_WRONLY | O_CREAT | O_TRUNC | O_BINARY, 0666)) == 0)
		{
			fprintf(output, "Cannot open output file %s\n", argv[2]);
			exit(-1);
		}
	}

	if((copybuf = malloc(COPY_BUF_SIZE) )== 0)
	{
		fprintf(output, "Cannot malloc() copy buf\n");
		exit(-1);
	}

	a_dbg_print(0, 0, "Reading sparse_header...\n");
	ret= read_all(in, &sparse_header, sizeof(sparse_header));
	if (ret != sizeof(sparse_header)) {
		fprintf(output, "Error reading sparse file header\n");
		exit(-1);
	}

	print_sparse_header(&sparse_header);

	if (sparse_header.magic != SPARSE_HEADER_MAGIC) {
		fprintf(output, "Bad magic\n");
		exit(-1);
	}

	if(sparse_header.major_version != SPARSE_HEADER_MAJOR_VER) {
		fprintf(output, "Unknown major version number\n");
		exit(-1);
	}

	if(sparse_header.file_hdr_sz > SPARSE_HEADER_LEN)
	{
		/* Skip the remaining bytes in a header that is longer than
		 * we expected.
		 */
		LSEEK64(in, sparse_header.file_hdr_sz - SPARSE_HEADER_LEN, SEEK_CUR);
	}

	if( (zerobuf = malloc(sparse_header.blk_sz)) == 0)
	{
		fprintf(output, "Cannot malloc() zero buf\n");
		exit(-1);
	}

	a_dbg_print(0, 0,
		"sparse_header.total_chunks=0x%08lX\n",
		sparse_header.total_chunks);
	FPRINTF_SEPARATION_BAR;

	for (i=0; i < sparse_header.total_chunks; i++)
	{
		a_dbg_print(0, 1, "LOAD CHUNK HEADER...\n");
		PRINT_FILEPOS(in, "input ");
		a_dbg_print(0, 0, "chunk header index=0x%08lX\n", i );
		ret= read_all(in, &chunk_header, sizeof(chunk_header));
		if(ret != sizeof(chunk_header))
		{
			fprintf(
				output,
				"ERROR: Reading chunk header. "
				"Wrong chunk header size=0x%lX\n",
				ret);
			exit(-1);
		}

		a_dbg_print(0, 0,
			"sparse_header.chunk_hdr_sz=0x%08lX\n",
			sparse_header.chunk_hdr_sz);
		if (sparse_header.chunk_hdr_sz > CHUNK_HEADER_LEN)
		{
			/* Skip the remaining bytes in a header that is longer than
			 * we expected.
			 */
			a_dbg_print(0, 0,
				"chunk_hdr_sz > 0x%08lX, skipping 0x%08lX bytes\n",
				CHUNK_HEADER_LEN,
				sparse_header.chunk_hdr_sz);

			LSEEK64(in, sparse_header.chunk_hdr_sz - CHUNK_HEADER_LEN, SEEK_CUR);
		}
		PRINT_FILEPOS(in, "input ");
		FPRINTF_SEPARATION_BAR;
		print_chunk_header(&chunk_header);
		switch (chunk_header.chunk_type)
		{
			case CHUNK_TYPE_RAW:
				a_dbg_print(0, 1, "CHUNK_TYPE: RAW (begin)\n");
				a_dbg_print(0, 0,
					"chunk_header.total_sz=0x%lX\n", chunk_header.total_sz);
				if(chunk_header.total_sz !=
					(sparse_header.chunk_hdr_sz +
					(chunk_header.chunk_sz * sparse_header.blk_sz)))
				{
					fprintf(output, "Bogus chunk size for chunk %d, type Raw\n", i);
					exit(-1);
				}
				PRINT_FILEPOS(in, "input ");
				total_blocks +=
					process_raw_chunk(
					in,
					out,
					chunk_header.chunk_sz,
					sparse_header.blk_sz,
					&crc32);
				PRINT_FILEPOS(in, "input ");
				a_dbg_print(-1, 0, "CHUNK_TYPE=RAW (end)\n");
				break;

			case CHUNK_TYPE_FILL:
				a_dbg_print(0, 1, "CHUNK_TYPE: FILL (begin)\n");
				if (chunk_header.total_sz
					!= (sparse_header.chunk_hdr_sz + sizeof(u32)) )
				{
					fprintf(output, "Bogus chunk size for chunk %d, type Fill\n", i);
					exit(-1);
				}
				PRINT_FILEPOS(in, "input ");
				total_blocks +=
					process_fill_chunk(
						in,
						out,
						chunk_header.chunk_sz,
						sparse_header.blk_sz,
						&crc32);
				a_dbg_print(-1, 0, "CHUNK_TYPE: FILL (end)\n");
				PRINT_FILEPOS(in, "input ");
				break;

			case CHUNK_TYPE_DONT_CARE:
				a_dbg_print(0, 1, "CHUNK_TYPE: DONT_CARE (begin)\n");
				PRINT_FILEPOS(in, "input ");
				if (chunk_header.total_sz != sparse_header.chunk_hdr_sz)
				{
					fprintf(
						output,
						"Bogus chunk size for chunk %d, type \"Dont_Care\"\n", i);
					exit(-1);
				}
				total_blocks +=
					process_skip_chunk(
						out,
						chunk_header.chunk_sz, sparse_header.blk_sz, &crc32);
				PRINT_FILEPOS(in, "input " );
				a_dbg_print(-1, 0, "CHUNK_TYPE: DONT_CARE (end)\n");
				break;

			case CHUNK_TYPE_CRC32:
				a_dbg_print(0, 1, "CHUNK_TYPE: CRC32 (begin)\n");
				PRINT_FILEPOS(in, "input ");
				process_crc32_chunk(in, crc32);
				PRINT_FILEPOS(in, "input ");
				a_dbg_print(-1, 0, "CHUNK_TYPE: CRC32 (end)\n");
				break;

			default:
				a_dbg_print(
					0, 0,
					"ERROR: UNKNOWN CHUNK TYPE 0x%4.4x\n",
					chunk_header.chunk_type);
		}

		a_dbg_print(-1, 0, "");
		FPRINTF_SEPARATION_BAR;
	}

	/* If the last chunk was a skip, then the code just did a seek, but
	 * no write, and the file won't actually be the correct size.  This
	 * will make the file the correct size.  Make sure the offset is
	 * computed in 64 bits, and the function called can handle 64 bits.
	 */
	if (ftruncate64(out, (u64)total_blocks * sparse_header.blk_sz)) {
		fprintf(output, "Error calling ftruncate() to set the image size\n");
		exit(-1);
	}

	close(in);
	close(out);

	if (sparse_header.total_blks != total_blocks) {
		fprintf(
			output,
			"Wrote %d blocks, expected to write %d blocks\n",
			 total_blocks,
			 sparse_header.total_blks);
		exit(-1);
	}

	fprintf(stderr, "Wrote \"%.256s\"\n", out_filename);
	fclose(output);
	exit(0);
	return(0);
}

// "k:\simg2img\simg2img.exe" -i "K:\mobile_devices\work\000_sm-g900f\000-img\orig\untar\cache.img.ext4" -o "e:\test.img"
// "k:\simg2img\simg2img.exe" "K:\mobile_devices\work\000_sm-g900f\000-img\orig\untar\cache.img.ext4" "e:\test.img"
